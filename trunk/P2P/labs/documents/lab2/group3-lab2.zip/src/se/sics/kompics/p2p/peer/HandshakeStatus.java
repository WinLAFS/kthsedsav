package se.sics.kompics.p2p.peer;

public enum HandshakeStatus {
ACCEPT,
REJECT,
}
