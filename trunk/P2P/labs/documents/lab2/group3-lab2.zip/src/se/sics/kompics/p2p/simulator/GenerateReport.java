package se.sics.kompics.p2p.simulator;

import se.sics.kompics.timer.SchedulePeriodicTimeout;
import se.sics.kompics.timer.Timeout;

public class GenerateReport extends Timeout {

//-------------------------------------------------------------------	
	public GenerateReport(SchedulePeriodicTimeout request) {
		super(request);
	}
}
