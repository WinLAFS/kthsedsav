package se.sics.kompics.p2p.simulator.launch;

public enum PeerType {
SEED,
LEECHER
}
