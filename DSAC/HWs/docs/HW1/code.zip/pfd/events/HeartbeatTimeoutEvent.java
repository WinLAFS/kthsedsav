package se.kth.ict.id2203.pfd.events;

import se.sics.kompics.timer.ScheduleTimeout;
import se.sics.kompics.timer.Timeout;

public class HeartbeatTimeoutEvent extends Timeout {

	public HeartbeatTimeoutEvent(ScheduleTimeout st) {
		super(st);
		// TODO Auto-generated constructor stub
	}



}
