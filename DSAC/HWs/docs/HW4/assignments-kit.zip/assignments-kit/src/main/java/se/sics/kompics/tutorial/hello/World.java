package se.sics.kompics.tutorial.hello;

import se.sics.kompics.Event;

public final class World extends Event {
}
