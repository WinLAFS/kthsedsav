package se.kth.ict.id2203.epfdfl.events;

import se.sics.kompics.timer.ScheduleTimeout;
import se.sics.kompics.timer.Timeout;

public class CheckTimeoutEvent extends Timeout {

	public CheckTimeoutEvent(ScheduleTimeout request) {
		super(request);
		// TODO Auto-generated constructor stub
	}



}
