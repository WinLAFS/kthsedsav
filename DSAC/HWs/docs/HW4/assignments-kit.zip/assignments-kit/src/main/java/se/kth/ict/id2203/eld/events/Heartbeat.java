package se.kth.ict.id2203.eld.events;

import se.kth.ict.id2203.pp2p.Pp2pDeliver;
import se.sics.kompics.address.Address;

public class Heartbeat extends Pp2pDeliver {

	public Heartbeat(Address source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
