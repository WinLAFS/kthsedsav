package se.kth.ict.id2203.uc;

import java.util.Set;

import se.kth.ict.id2203.application.Application0Init;
import se.sics.kompics.address.Address;

public class Application4Init extends Application0Init {

	public Application4Init(String commandScript, Set<Address> neighborSet,
			Address self) {
		super(commandScript, neighborSet, self);
		// TODO Auto-generated constructor stub
	}

}
