package se.kth.ict.id2203.lpb.events;


import se.sics.kompics.timer.ScheduleTimeout;
import se.sics.kompics.timer.Timeout;

public class GossipTimeoutEvent extends Timeout {

	public GossipTimeoutEvent(ScheduleTimeout request) {
		super(request);
		// TODO Auto-generated constructor stub
	}



}
